# DataRefine Database Importer

First-party DataRefine Studio plugin for importing rows from Postgres, MySQL, SQL Server, SQLite, DuckDB, and Snowflake.

## Install

Use the DataRefine Studio Extensions panel and choose **Import plugin**. The same zip can be served as a marketplace artifact when the marketplace catalogue points at it.

This plugin requires the DataRefine Studio core view component `database-import` introduced with the matching application patch. It has no Python, network, cloud, or provider permissions.

## What it does

- Uses the existing connection model and saved connection storage.
- Supports manual fields, saved connections, SSL, optional SSH tunnelling, and connection testing.
- Accepts a table name or SQL query.
- Imports Top N, Bottom N, Custom row count, or All rows.
- Requires an order expression for Bottom N so the selection is deterministic.
- Opens the result through the normal DataRefine workspace session API; credentials are not written to plugin messages or logs.

For Bottom N, the order expression is used descending and the selected rows are returned by the database. All rows is intentionally explicit because it may use substantial memory.
