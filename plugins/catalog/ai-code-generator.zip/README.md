# DataRefine AI Code Generator

A separate first-party DataRefine Studio plugin for generating cleaning code from a complete sheet profile.

## Install

Import `DataRefineAiCodeGenerator.zip` through the DataRefine Extensions panel, or publish the same ZIP as a verified marketplace artifact. The matching DataRefine core view component `ai-code-generator` must be present in the application.

This plugin is independent from **AI Worker Cleaner** and **Database Importer**. Do not merge their manifests or ZIP artifacts.

## Workflow

1. Open a data sheet.
2. Open **AI Code Generator** from the activity bar.
3. Press **Scan whole sheet**. The scan reads the complete current sheet through the existing profile and metrics APIs, while keeping only a bounded preview sample for the prompt.
4. Choose **Python**, **SQL**, or **JavaScript**, optionally describe the cleaning goal, and press **Generate**.
5. Review or edit the generated code in the plugin.
6. Press **Inject into editor**. Python is placed in the Python editor, SQL in the SQL editor, and JavaScript in the JavaScript editor; the matching bottom editor opens.
7. Press **Inject & run** when ready. The code is injected and executed by the existing DataRefine workspace runner, preserving normal results, history, and undo behavior.

Generation is gated until the current sheet scan completes. Changing the sheet invalidates the previous scan. No code is executed automatically after generation.

## Runtime and privacy

The plugin does not call an AI provider, Cloud AI, or credential store directly. It uses the central DataRefine AI runtime/provider router and the existing local/BYOK AI proxy. Cloud AI is not used for this sheet-aware code generation because Cloud jobs do not receive local sheet rows; select Local or BYOK in the central AI settings.

The plugin requests no credentials, database access, filesystem access, network access, subprocess access, or provider permissions. It does not print provider keys, database credentials, tokens, or raw rows to logs. The bounded sample is sent only through the selected central Local/BYOK runtime for the requested generation call.
