# DataRefine AI Worker Cleaner

First-party DataRefine Studio plugin for long-running, visible AI cleaning work.

## Install

Import the ZIP through the DataRefine Extensions panel, or publish the same ZIP as a verified marketplace artifact. The matching DataRefine core view component `ai-worker-cleaner` must be present in the application.

## Workflow

1. Open a data sheet.
2. Open **AI Worker Cleaner** from the activity bar.
3. Press **Scan sheet**. The plugin profiles the current sheet, counts rows/columns/missing values/duplicates, and inspects a bounded local sample.
4. Press **Start cleaning workers**. The existing central DataRefine AI runtime builds a cleaning plan and reports Detect, Plan, and Preview progress.
5. Review the proposed operations and confidence threshold.
6. Under **Pre-approved operations**, select operation types that may edit automatically after planning. Save the policy.
7. Press **Apply remaining** for proposals that are not pre-approved.

Pre-approved operation types are standing user permission: matching operations are applied directly after the worker plan completes without another prompt. Unselected operations remain pending until Apply. The plugin displays scanner, AI planner, and cleaner worker stages, progress percentage, elapsed work time, proposed cells, and edited cells. The central pipeline continues while the user switches away from the sidebar. Cloud job status is polled and can be cancelled.

## Runtime and privacy

The plugin does not call providers, Cloud AI, credits, or credentials directly. It uses the central DataRefine AI runtime and current router settings. Local and BYOK cleaning uses the local sheet session. Cloud jobs remain server-authorized and do not receive local sheet rows; a Cloud job therefore cannot edit local cells. Use Local or BYOK when actual sheet edits are required.

Changes are not applied until either a selected pre-approved operation policy authorizes them or the user presses Apply. The policy is an explicit standing permission and is shown in the plugin UI. The plugin requests no Python, filesystem, network, subprocess, or cloud permissions.
