// Column Cleaner Pro — sample marketplace plugin stub
export function activate() { console.log('demo-column-cleaner active'); }
