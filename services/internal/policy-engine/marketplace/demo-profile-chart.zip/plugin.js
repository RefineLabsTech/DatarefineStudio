// Profile Chart — sample marketplace plugin stub
export function activate() { console.log('demo-profile-chart active'); }
