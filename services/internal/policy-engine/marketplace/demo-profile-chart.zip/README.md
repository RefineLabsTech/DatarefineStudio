# Profile Chart

Adds a sidebar view with quick per-column statistic charts for the open sheet.
